A Pen created at CodePen.io. You can find this one at http://codepen.io/rhernando/pen/vjGxH.

 A GSAP powered cross-browser 3D flip card sample.

Basically it uses two different elements that are animated at the same time to create the flip card, without using preserve-3d which is not supported by IE.